# FILE: test_fixes.py
import json
from core.rules_engine import apply_rules
from core.inference import detect_meaning_shifts

test_input = "make sure that the valve is operable."

print("=" * 60)
print("🧪 TESTING RULE 8.6 (Abbreviations)")
print("=" * 60)

rules = apply_rules(test_input)
rule_8_6 = [r for r in rules if r.rule_id == "8.6"][0]
print(f"Input: '{test_input}'")
print(f"Rule 8.6 Result: {rule_8_6.comment}")
print(f"✅ PASS" if rule_8_6.passed else "❌ FAIL")

print("\n" + "=" * 60)
print("🧪 TESTING RULE 9.5 (Pronouns)")
print("=" * 60)

rule_9_5 = [r for r in rules if r.rule_id == "9.5"][0]
print(f"Rule 9.5 Result: {rule_9_5.comment}")
print(f"✅ PASS (Should be close to passing)" if rule_9_5.passed else "⚠️  May flag pronouns")

print("\n" + "=" * 60)
print("🧪 TESTING MEANING SHIFT DETECTION")
print("=" * 60)

shifts = detect_meaning_shifts(test_input)
print(f"Meaning shifts detected: {len(shifts)}")
if shifts:
    for shift in shifts:
        print(f"  - {shift['word']}: {shift['message']}")
else:
    print("✅ No meaning shifts (Correct!)")

print("\n" + "=" * 60)
print("✅ All tests complete!")
print("=" * 60)