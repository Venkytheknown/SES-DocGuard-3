"""
main.py – Entry point for the ASD‑STE Checker powered by Gen‑AI (Local & Offline)
Implements:
 • text preprocessing
 • rule engine evaluation
 • dictionary-based validation (approved/unapproved words)
 • AI feedback via GPT4All/Llama
Outputs structured JSON results under /reports
"""

import argparse
import json
import logging
from pathlib import Path
from datetime import datetime
from typing import List

# Core modules
from core.preprocess import clean_text
from core.rules_engine import apply_rules, RuleResult # Import RuleResult for type hinting/structure
from core.dictionary_check import analyze_text
from core.inference import get_model, analyze_ste

# Utility modules
from utils.io_utils import read_file, write_json
from utils.logger import setup_logging


def run_checker(input_path: str, output_path: str):
    """Complete ASD‑STE checker pipeline."""
    logging.info(f"Running ASD‑STE Checker on {input_path}")

    # ------------------------------------------------------------------
    # 1️⃣ Load input text
    # ------------------------------------------------------------------
    raw_text = read_file(input_path)
    if not raw_text.strip():
        logging.warning("Input file is empty or contains only whitespace. Skipping analysis.")
        print("💡: Input file is empty or contains only whitespace. No analysis performed.")
        return

    logging.info(f"Loaded text length: {len(raw_text)} characters")

    # ------------------------------------------------------------------
    # 2️⃣ Clean and preprocess text
    # ------------------------------------------------------------------
    prepared_text = clean_text(raw_text)
    logging.info("Preprocessing complete.")

    # ------------------------------------------------------------------
    # 3️⃣ Apply rule-based checks (from rules_engine.py)
    # ------------------------------------------------------------------
    # rules_engine.apply_rules returns List[RuleResult]
    rule_results: List[RuleResult] = apply_rules(prepared_text)
    
    # Filter RuleResults to count actual violations (passed=False)
    # Ensure to only count those stemming from actual pattern matches, not 'no pattern'
    actual_rule_violations = [r for r in rule_results if not r.passed and not r.comment.startswith("⚠️ Review")]
    violations_count = len(actual_rule_violations)
    
    logging.info(f"Rule evaluation complete: {violations_count} actual violations found.")

    # ------------------------------------------------------------------
    # 4️⃣ Apply dictionary-based validation (Approved/Unapproved words)
    # ------------------------------------------------------------------
    dict_warnings = analyze_text(prepared_text) # dict_warnings is a List[str]
    logging.info(f"{len(dict_warnings)} dictionary warnings detected.")
    
    # Format dictionary warnings to be passed to AI prompt
    formatted_dict_warnings = ""
    if dict_warnings:
        formatted_dict_warnings = "\n\n**DICTIONARY WARNINGS:**\n" + "\n".join([f"- {w}" for w in dict_warnings])
        formatted_dict_warnings += "\n**IMPORTANT: Address these vocabulary issues in your rewrite.**\n"
        

    # ------------------------------------------------------------------
    # 5️⃣ Run AI analysis (Model = GPT4All or Llama)
    # ------------------------------------------------------------------
    model = get_model() # Loads the model instance once
    # Pass formatted_dict_warnings to analyze_ste
    ai_result = analyze_ste(model, prepared_text, formatted_dict_warnings) 
    
    ai_feedback = ai_result["feedback"]
    meaning_shifts_for_report = ai_result.get("meaning_shifts", []) 
    
    logging.info("AI feedback generation complete.")
    logging.info(f"Detected {len(meaning_shifts_for_report)} meaning shift violations via AI module.")

    # ------------------------------------------------------------------
    # 6️⃣ Aggregate all results → structured JSON
    # ------------------------------------------------------------------
    combined_output = {
        "file": str(input_path),
        "summary": {
            "timestamp": datetime.now().isoformat(),
            "total_rules_evaluated": len(rule_results),
            "rule_violations": violations_count,
            "dictionary_warnings": len(dict_warnings),
            "meaning_shifts_detected": len(meaning_shifts_for_report)
        },
        "rule_results": [r.__dict__ for r in rule_results], # Convert RuleResult objects to dictionaries for JSON
        "dictionary_warnings": dict_warnings, 
        "meaning_shifts": meaning_shifts_for_report, 
        "ai_feedback": ai_feedback
    }

    # ------------------------------------------------------------------
    # 7️⃣ Save results
    # ------------------------------------------------------------------
    write_json(output_path, combined_output)
    logging.info(f"Results saved to {output_path}")
    
     # ------------------------------------------------------------------
    # 8️⃣ Print summary to console
    # ------------------------------------------------------------------
    print(f"\n✅ Analysis complete. Results saved to: {output_path}")
    print(f"\n📊 Summary for '{Path(input_path).name}':")
    print(f"   • Total rules evaluated: {len(rule_results)}")
    print(f"   • Rule violations detected: {violations_count}")
    print(f"   • Dictionary warnings: {len(dict_warnings)}")
    print(f"   • Meaning shifts detected: {len(meaning_shifts_for_report)}")
    
    # Print compliance score
    compliance_score = max(0, 100 - (violations_count * 5) - (len(dict_warnings) * 8))
    print(f"\n📈 Compliance Score: {compliance_score}/100")
    
    # Print detailed violations if any
    if violations_count > 0:
        print(f"\n⚠️  Rule Violations ({violations_count} found):")
        for result in actual_rule_violations[:10]:  # Show first 10
            print(f"   • Rule {result.rule_id}: {result.comment[:100]}...")
    
    if dict_warnings:
        print(f"\n📖 Unapproved Words ({len(dict_warnings)} found):")
        for warning in dict_warnings[:10]:  # Show first 10
            print(f"   • {warning[:100]}...")
    
    if meaning_shifts_for_report:
        print(f"\n🔍 Meaning Shifts ({len(meaning_shifts_for_report)} found):")
        for shift in meaning_shifts_for_report:
            print(f"   • '{shift.get('word', 'N/A').upper()}': {shift.get('message', 'N/A')[:80]}...")
    
    print(f"\n✅ Full report saved to: {output_path}\n")

# ======================================================================
# 🚀 CLI Entry Point
# ======================================================================
if __name__ == "__main__":
    setup_logging()

    parser = argparse.ArgumentParser(
        description="Offline ASD‑STE Checker powered by Gen‑AI (GPT4All/Llama)"
    )
    parser.add_argument("--input", required=True,
                        help="Path to input text file (e.g. samples/test.txt)")
    parser.add_argument("--output", default="reports/result.json",
                        help="Path to save JSON results")
    args = parser.parse_args()

    try:
        run_checker(args.input, args.output)
    except Exception as e:
        logging.exception(f"❌ A critical error occurred during checker execution: {e}")
        print(f"❌ Checker failed: {e}. Please check the logs for more details.")