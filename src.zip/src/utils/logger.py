"""
utils/logger.py — Logging configuration
"""
import logging
from pathlib import Path
from datetime import datetime

def setup_logging():
    """Configure logging to console and file."""
    log_dir = Path("assets/logs")
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / f"run_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"

    logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(log_file, encoding="utf-8"),
        logging.StreamHandler()                # ⇐ Optional – but make console UTF‑8
    ]
)
    logging.info(f"Logging started: {log_file}")