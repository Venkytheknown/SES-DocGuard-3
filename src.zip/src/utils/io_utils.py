"""
utils/io_utils.py — File I/O helpers
"""
import json
from pathlib import Path

def read_file(filepath: str) -> str:
    path = Path(filepath)
    with open(path, "r", encoding="utf-8") as file:
        return file.read()

def write_json(filepath: str, data: dict):
    path = Path(filepath)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)