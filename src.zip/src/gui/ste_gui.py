"""
gui/ste_gui.py — Advanced GUI for ASD‑STE Checker
Integrated with:
 • Rule evaluation
 • Dictionary validation
 • AI feedback via GPT4All or Llama
 • Meaning shift detection
"""

import sys, os
sys.path.append(os.path.join(os.path.dirname(__file__), ".."))  # allow core imports

import tkinter as tk
from tkinter import scrolledtext, filedialog, messagebox
import threading
import logging
from pathlib import Path

# === Core modules ===
from core.preprocess import clean_text
from core.rules_engine import apply_rules
from core.dictionary_check import analyze_text
from core.inference import get_model, analyze_ste

# === Utils ===
from utils.logger import setup_logging

class STECheckerGUI:
    """Main Tkinter-based interface for ASD‑STE Checker."""

    def __init__(self, root):
        self.root = root
        self.root.title("ASD‑STE Checker (Gen‑AI + Rule + Dictionary)")
        self.root.geometry("1000x700")
        self.root.configure(bg="#ECEFF1")

        # -------------- Chat Output Box --------------
        self.chat_box = scrolledtext.ScrolledText(
            root, wrap=tk.WORD, state="disabled",
            bg="white", fg="#212121", font=("Segoe UI", 10)
        )
        self.chat_box.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)

        # -------------- Input Frame --------------
        input_frame = tk.Frame(root, bg="#ECEFF1")
        input_frame.pack(fill=tk.X, side=tk.BOTTOM)

        self.entry = tk.Entry(input_frame, font=("Segoe UI", 11), bg="#FAFAFA", fg="#212121")
        self.entry.pack(fill=tk.X, side=tk.LEFT, padx=10, pady=10, expand=True)
        self.entry.bind("<Return>", self.on_send)

        send_btn = tk.Button(
            input_frame, text="Analyze", command=self.on_send,
            bg="#1976D2", fg="white", font=("Segoe UI", 10, "bold"), width=10
        )
        send_btn.pack(side=tk.RIGHT, padx=(0, 10), pady=10)

        # -------------- Menu Bar --------------
        menu = tk.Menu(root)
        file_menu = tk.Menu(menu, tearoff=0)
        file_menu.add_command(label="Open File…", command=self.load_file)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=root.quit)
        menu.add_cascade(label="File", menu=file_menu)
        root.config(menu=menu)

        # -------------- Initialize logging and model --------------
        setup_logging()
        self.post_message("💡", "Initializing model. Please wait...")
        try:
            self.model = get_model()
            self.post_message("✅", "Model loaded successfully. Ready for analysis!\n")
        except Exception as e:
            self.post_message("❌", f"Model load failed:\n{e}")

    # ============================================================
    # Utility Methods
    # ============================================================

    def post_message(self, sender: str, message: str, color="#212121"):
        """Append a formatted message to the chat display."""
        self.chat_box.configure(state="normal")
        self.chat_box.insert(tk.END, f"{sender}: {message}\n\n", ("color",))
        self.chat_box.tag_config("color", foreground=color)
        self.chat_box.configure(state="disabled")
        self.chat_box.yview(tk.END)

    # ============================================================
    # Actions
    # ============================================================

    def on_send(self, event=None):
        """Triggered when user hits Enter or presses Analyze."""
        user_input = self.entry.get().strip()
        if not user_input:
            return
        self.entry.delete(0, tk.END)
        self.post_message("🧩 Input", user_input, "#0D47A1")
        threading.Thread(target=self.process_text, args=(user_input,), daemon=True).start()

    def process_text(self, text: str):
        """Run all analysis steps on the user-entered text."""
        try:
            prepared = clean_text(text)

            # Step 1: Rule Engine
            rule_results = apply_rules(prepared)
            rule_violations = [r for r in rule_results if not r.passed]
            if rule_violations:
                violations_text = "\n".join([f"{r.rule_id}: {r.comment}" for r in rule_violations])
            else:
                violations_text = "✅ No rule violations detected."
            self.post_message("📘 Rule Summary", violations_text, "#1B5E20")

            # Step 2: Dictionary Validation
            dict_warnings = analyze_text(prepared)
            if dict_warnings:
                vocab_text = "\n".join(dict_warnings)
            else:
                vocab_text = "✅ No dictionary issues detected."
            self.post_message("📚 Dictionary Warnings", vocab_text, "#4E342E")

            # Step 3: AI Feedback with Meaning Shift Detection
            feedback_obj = analyze_ste(self.model, prepared)
            ai_feedback = feedback_obj.get("feedback", "(no feedback)")
            meaning_shifts = feedback_obj.get("meaning_shifts", [])
            
            # Display Meaning Shift Violations
            if meaning_shifts:
                meaning_shift_text = "\n".join([
                    f"{shift['word']}: {shift['message']} ({shift['count']} match(es))" 
                    for shift in meaning_shifts
                ])
                self.post_message("🔍 Meaning Shift Violations", meaning_shift_text, "#7B1FA2")
            else:
                self.post_message("🔍 Meaning Shift Violations", "✅ No meaning shift violations detected.", "#7B1FA2")
            
            self.post_message("🤖 AI Feedback", ai_feedback, "#BF360C")

        except Exception as e:
            logging.exception(f"Processing error: {e}")
            self.post_message("❌ Error", str(e), "#B71C1C")

    def load_file(self):
        """Open a text file, show preview, allow user to analyze it."""
        file_path = filedialog.askopenfilename(
            title="Select text file",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )
        if not file_path:
            return
        try:
            content = Path(file_path).read_text(encoding="utf-8")
            self.entry.delete(0, tk.END)
            snippet = content[:800]
            self.entry.insert(0, snippet)
            messagebox.showinfo(
                "File loaded",
                f"File '{Path(file_path).name}' loaded. Press 'Analyze' to check."
            )
        except Exception as e:
            messagebox.showerror("Error", f"Could not load file: {e}")


# ============================================================
#  Application Entrypoint
# ============================================================
if __name__ == "__main__":
    root = tk.Tk()
    app = STECheckerGUI(root)
    root.mainloop()