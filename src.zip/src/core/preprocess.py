"""
core/preprocess.py — Text normalization & cleanup
"""
import re

def clean_text(text: str) -> str:
    """Basic cleanup of input text before rule analysis."""
    text = re.sub(r"\s+", " ", text)
    text = text.strip()
    text = text.replace("“", "\"").replace("”", "\"")
    return text