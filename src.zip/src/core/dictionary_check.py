"""
core/dictionary_check.py — STE vocabulary validator
Loads Excel dictionary and checks text words, including basic Part-of-Speech (POS) heuristics.
"""

import pandas as pd
import re
from pathlib import Path
import logging

# Optional: NLTK for more robust POS tagging. Install with: pip install nltk
# import nltk
# from nltk.tokenize import word_tokenize
# from nltk.tag import pos_tag

DICT_PATH = Path("configs/asd_ste_dictionary.xlsx")

# Initialize dictionary as empty DataFrame
dictionary_df = pd.DataFrame()

def load_dictionary():
    """Load STE dictionary from Excel file."""
    global dictionary_df
    try:
        dictionary_df = pd.read_excel(DICT_PATH)
        # Convert relevant columns to string and then lowercase for robust matching
        dictionary_df["WordLower"] = dictionary_df["Word"].astype(str).str.lower()
        if "PartOfSpeech" in dictionary_df.columns:
            # Ensure PartOfSpeech is treated as string before lowercasing and splitting
            dictionary_df["PartOfSpeechClean"] = dictionary_df["PartOfSpeech"].astype(str).str.lower().str.strip()
        else:
            dictionary_df["PartOfSpeechClean"] = "" # Add empty column if not present
            
        logging.info(f"Loaded STE dictionary with {len(dictionary_df)} entries from {DICT_PATH}")
        return dictionary_df
    except FileNotFoundError:
        logging.error(f"STE dictionary file not found at: {DICT_PATH}")
        dictionary_df = pd.DataFrame()
        return dictionary_df
    except Exception as e:
        logging.error(f"Could not load STE dictionary from {DICT_PATH}: {e}")
        dictionary_df = pd.DataFrame()
        return dictionary_df


def check_word(word: str, pos_tag_hint: str = None):
    """
    Return dictionary entry(ies) for a given word, optionally considering a Part-of-Speech (POS) hint.
    Returns a list of matching entries (dictionaries), as multiple POS forms might exist.
    """
    if dictionary_df.empty:
        load_dictionary()
    
    if dictionary_df.empty:
        return [] # Return empty list if dictionary failed to load
    
    word_lower = word.lower()
    
    # Filter by word first (case-insensitive)
    matches_df = dictionary_df.loc[dictionary_df["WordLower"] == word_lower].copy()
    
    if matches_df.empty:
        return [] # No entries for this word
    
    # If a POS tag hint is provided, further refine matches
    if pos_tag_hint and "PartOfSpeechClean" in matches_df.columns:
        # Normalize the POS tag hint
        pos_tag_hint_lower = pos_tag_hint.lower()
        if pos_tag_hint_lower.startswith('vb'): pos_tag_hint_lower = 'v'
        elif pos_tag_hint_lower.startswith('nn'): pos_tag_hint_lower = 'n'
        elif pos_tag_hint_lower.startswith('jj'): pos_tag_hint_lower = 'adj'
        elif pos_tag_hint_lower.startswith('rb'): pos_tag_hint_lower = 'adv'
        elif pos_tag_hint_lower.startswith('in'): pos_tag_hint_lower = 'prep'
        elif pos_tag_hint_lower.startswith('cc'): pos_tag_hint_lower = 'conj'
            
        # Filter for entries where the PartOfSpeech includes our hint
        pos_filtered_df = matches_df[
            matches_df["PartOfSpeechClean"].apply(lambda x: pos_tag_hint_lower in x.split(','))
        ]
        
        if not pos_filtered_df.empty:
            matches_df = pos_filtered_df
        # If POS filtering yields no results, we still fall back to general word matches,
        # but for this function, we prioritize the hint if it leads to matches.
        # The calling 'analyze_text' determines how to use results.

    # Convert matching rows to a list of dictionaries
    results = []
    for _, row in matches_df.iterrows():
        results.append({
            "Word": row["Word"],
            "Status": row["Status"],
            "Alternative": row["Alternative"] if pd.notna(row["Alternative"]) else "",
            "PartOfSpeech": row["PartOfSpeechClean"] if "PartOfSpeechClean" in row else ""
        })
    return results


def analyze_text(text: str):
    """
    Scan a text and collect all dictionary-related warnings, using basic POS heuristics.
    """
    if dictionary_df.empty:
        load_dictionary() # Ensure dictionary is loaded
    
    if dictionary_df.empty:
        logging.warning("Dictionary is empty, cannot perform analysis.")
        return []

    findings = []
    
    # Use a tokenizer that respects word boundaries but keeps punctuation attached for context if needed
    # Using a simple iterable for words
    words_only = re.findall(r"\b[A-Za-z\-']+\b", text)
    
    for i, token in enumerate(words_only):
        # We need more context for smart POS hinting, but for a simple token list,
        # we try to guess based on common cases.
        guessed_pos_hint = None
        
        # --- Heuristics for common STE-problematic words and their POS ---
        if token.lower() in ["test", "dim", "perform", "monitor", "apply", "check", "measure"]: # Words commonly restricted to specific POS or have preferred alternatives
            # Very basic heuristic: if it's the first word of the text/sentence-like fragment, guess verb (imperative)
            # This is extremely weak and will have many false positives/negatives without actual sentence parsing.
            if i == 0 or (i > 0 and (words_only[i-1].endswith('.') or words_only[i-1].endswith('!') or words_only[i-1].endswith('?'))):
                 guessed_pos_hint = 'v' # Guessing it might be an imperative verb
            
        # --- End Heuristics ---

        # Get all relevant dictionary entries for the token, potentially with POS hint
        word_entries = check_word(token, guessed_pos_hint)

        if not word_entries:
            continue # Word not found in dictionary

        # Prioritize unapproved entries.
        # If there's an exact POS match for an unapproved word, flag it.
        # If there's no POS hint, or a general entry is unapproved, flag it.
        
        # Find if there's any unapproved entry, potentially matching the hint
        flagged = False
        for entry in word_entries:
            if entry["Status"] in ("Unapproved", "Deleted"):
                # If a specific POS hint led to this unapproved entry, it's a strong match
                # Otherwise, it's a general unapproved word.
                alternative_text = entry["Alternative"] if entry["Alternative"] else "No specific alternative given"
                
                # Custom message for specific words to guide user better
                message_details = ""
                if token.lower() == "test" and entry["PartOfSpeech"] == "v":
                    message_details = " (Rule 1.2: 'Test' is approved as noun, not verb. STE: 'Do a test')"
                elif token.lower() == "dim" and entry["PartOfSpeech"] == "v":
                    message_details = " (Rule 1.2: 'Dim' is approved as adjective, not verb. STE: 'The lights become dim')"
                
                findings.append(
                    f"'{entry['Word']}' (POS: '{entry['PartOfSpeech']}') is {entry['Status']} in STE dictionary{message_details}. Suggested alternative: '{alternative_text}'"
                )
                flagged = True
                break # Flag first unapproved entry and move on
        
        # If not flagged by a POS-specific unapproved entry,
        # and there's a mix of approved/unapproved without clear POS hint from context,
        # you might want to add a general warning about ambiguity.
        # For now, we only flag explicit "Unapproved" or "Deleted" entries.
        
    return findings


# Load dictionary on module import
load_dictionary()