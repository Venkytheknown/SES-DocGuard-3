"""
core/inference.py — Unified local inference engine (GPT4All or Llama)
FIXED VERSION 3: Adds post‑rewrite dictionary validation loop for full STE compliance.
"""

import sys
import os
from pathlib import Path
import logging
import inspect
import re

# Add project root to Python path
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, project_root)

from core.config import ENGINE, MODEL_PATH, MAX_TOKENS, N_THREADS
from core import dictionary_check  # ✅ New import for post‑rewrite validation

_model_instance = None


# ============================================================
# Meaning Shift Detection
# ============================================================
def detect_meaning_shifts(text: str) -> list:
    """Enhanced context-aware meaning shift detection for Rule 1.3 specific to inference.
    Returns a list of dictionaries describing violations."""
    meaning_shift_patterns = [
        {
            "word": "follow",
            "pattern": r"\bfollow\s+(?:the\s+)?(?:manufacturer[']?s\s+)?(?:safety|instructions|guidelines|rules|procedures|directives)\b",
            "message": "'follow' used as 'obey' - approved meaning is 'come after'. Use 'obey' instead.",
            "severity": "warning"
        },
        {
            "word": "fall",
            "pattern": r"\bfall\s+(?:below|under|short|off|away|back)\b",
            "message": "'fall' used as 'decrease' - approved meaning is 'move down by gravity'. Use 'decrease' or 'go down' instead.",
            "severity": "warning"
        },
        {
            "word": "optimize",
            "pattern": r"\boptimize\b",
            "message": "'optimize' not in STE dictionary. Use 'set for best operation' or 'adjust for maximum efficiency'.",
            "severity": "error"
        },
        {
            "word": "apparent",
            "pattern": r"\bapparent\b",
            "message": "'apparent' deleted from STE dictionary. Use 'clear', 'obvious', or 'visible' instead.",
            "severity": "error"
        }
    ]
    
    violations = []
    for shift in meaning_shift_patterns:
        matches = re.findall(shift["pattern"], text, re.IGNORECASE)
        if matches:
            violations.append({
                "word": shift["word"],
                "message": shift["message"],
                "severity": shift["severity"],
                "count": len(matches),
                "suggestion": shift.get("suggestion", "") 
            })
    
    return violations


# ============================================================
# Sentence Utilities
# ============================================================
def count_sentences(text: str) -> int:
    text = text.strip()
    if not text:
        return 0
    sentences = re.split(r'[.!?]+', text)
    sentences = [s.strip() for s in sentences if s.strip()]
    if len(sentences) == 0 and text:
        return 1
    return len(sentences)


def split_into_sentences(text: str) -> list:
    text = text.strip()
    if not text:
        return []
    sentences = re.split(r'[.!?]+', text)
    sentences = [s.strip() for s in sentences if s.strip()]
    if len(sentences) == 0 and text:
        return [text]
    return sentences


# ============================================================
# AI Response Extraction
# ============================================================
def extract_ai_rewrites(ai_response: str, original_text: str) -> list:
    if not ai_response or not ai_response.strip():
        logging.warning("AI response is empty")
        return []
    
    expected_count = count_sentences(original_text)
    logging.info(f"Expected sentence count: {expected_count}")
    
    cleaned = ai_response.strip()
    
    if "*** BEGIN USER TEXT ***" in cleaned:
        cutoff = cleaned.find("*** END USER TEXT ***")
        if cutoff != -1:
            cleaned = cleaned[cutoff + len("*** END USER TEXT ***"):].strip()
    
    meta_phrases = [
        "Here is the rewrite:", "Revised:", "Improved:", "Output:",
        "STE-compliant version:", "As an STE-compliant writer, here is the revised text:"
    ]
    for phrase in meta_phrases:
        cleaned = re.sub(r'^\s*' + re.escape(phrase) + r'\s*', '', cleaned, flags=re.IGNORECASE | re.MULTILINE)
        cleaned = re.sub(r'\s*' + re.escape(phrase) + r'\s*', ' ', cleaned, flags=re.IGNORECASE)
    
    extracted_sentences = []

    numbered_pattern = r'^\s*(\d+)\.\s*(.+?)(?=\n\s*\d+\.|\n*$|\Z)'
    numbered_matches = re.findall(numbered_pattern, cleaned, re.MULTILINE | re.DOTALL)
    if numbered_matches:
        extracted_sentences = [m[1].strip().rstrip('.') for m in numbered_matches]
        if len(extracted_sentences) >= expected_count:
            return extracted_sentences[:expected_count]

    bracketed_pattern = r'\[([^\]]+)\]'
    bracketed_matches = re.findall(bracketed_pattern, cleaned)
    if bracketed_matches:
        extracted_sentences = [m.strip().rstrip('.') for m in bracketed_matches]
        if len(extracted_sentences) >= expected_count:
            return extracted_sentences[:expected_count]

    lines = [line.strip() for line in cleaned.split('\n') if line.strip()]
    sentence_lines = []
    for line in lines:
        if not line:
            continue
        if any(skip in line.lower() for skip in ['rewrite', 'suggestion', 'example:', 'ste-compliant']):
            continue
        if len(line.split()) < 3:
            continue
        sentence_lines.append(line.rstrip('.'))
    if sentence_lines:
        return sentence_lines[:expected_count]

    split_sentences = re.split(r'[.!?]+', cleaned)
    cleaned_sentences = [s.strip() for s in split_sentences if s.strip() and len(s.split()) >= 3]
    if cleaned_sentences:
        return cleaned_sentences[:expected_count]

    logging.warning("❌ Failed to extract sentences from AI response.")
    return []


# ============================================================
# Basic Rule-Based Fallback Rewrite
# ============================================================
def apply_basic_ste_compliance(sentence: str, meaning_shifts_feedback: list, dict_warnings_feedback: str) -> str:
    ste_sentence = sentence.strip()
    if dict_warnings_feedback:
        for line in dict_warnings_feedback.split('\n'):
            match = re.search(r"'(.*?)'.*?Suggested alternative:\s*'(.*?)'", line)
            if match:
                unapproved_word = match.group(1)
                suggested_alt = match.group(2)
                if suggested_alt and suggested_alt not in ["—", "No specific alternative given"]:
                    pattern = r'\b' + re.escape(unapproved_word) + r'\b'
                    ste_sentence = re.sub(pattern, suggested_alt, ste_sentence, flags=re.IGNORECASE)
    for shift_info in meaning_shifts_feedback:
        word_to_check = shift_info['word']
        if word_to_check.lower() in ste_sentence.lower():
            corrections = {
                "follow": "obey",
                "fall": "decrease",
                "optimize": "set for best operation",
                "apparent": "clear"
            }
            ste_sentence = re.sub(r'\b' + word_to_check + r'\b', corrections[word_to_check], ste_sentence, flags=re.IGNORECASE)
    ste_sentence = re.sub(r'\bprior\s+to\b', 'before', ste_sentence, flags=re.IGNORECASE)
    ste_sentence = re.sub(r'\bin\s+order\s+to\b', 'to', ste_sentence, flags=re.IGNORECASE)
    ste_sentence = re.sub(r'\s+', ' ', ste_sentence).strip()
    if ste_sentence:
        ste_sentence = ste_sentence[0].upper() + ste_sentence[1:]
    return ste_sentence


def generate_fallback_rewrite(text: str, meaning_shifts_feedback: list, dict_warnings_feedback: str) -> str:
    original_sentences = split_into_sentences(text)
    ste_sentences = []
    for i, s in enumerate(original_sentences):
        ste_sentences.append(f"{i+1}. {apply_basic_ste_compliance(s, meaning_shifts_feedback, dict_warnings_feedback)}")
    return "\n".join(ste_sentences)


# ============================================================
# Model Loader
# ============================================================
def get_model():
    global _model_instance
    if _model_instance is not None:
        return _model_instance

    if ENGINE.lower() == "gpt4all":
        from gpt4all import GPT4All
        model_path = Path(MODEL_PATH)
        _model_instance = GPT4All(
            model_name=str(model_path.name),
            model_path=str(model_path.parent),
            allow_download=False,
            device="cpu",
            n_threads=N_THREADS
        )
        logging.info("GPT4All model loaded (offline).")

    elif ENGINE.lower() == "llama":
        from llama_cpp import Llama
        _model_instance = Llama(
            model_path=str(MODEL_PATH),
            n_ctx=MAX_TOKENS,
            n_threads=N_THREADS,
            use_mmap=True,
            verbose=False
        )
        logging.info("Llama model loaded (offline).")

    else:
        raise ValueError(f"Unsupported ENGINE '{ENGINE}'.")
    return _model_instance


# ============================================================
# Main Analysis Function (Updated v3)
# ============================================================
def analyze_ste(model, text: str, formatted_dict_warnings: str = "") -> dict:
    """Run ASD‑STE100 compliance analysis, now with post‑rewrite validation."""

    if not text.strip():
        return {"feedback": "Empty input.", "meaning_shifts": []}

    meaning_shifts = detect_meaning_shifts(text)
    sentence_count = count_sentences(text)

    meaning_shift_context = ""
    if meaning_shifts:
        meaning_shift_context = "\n\n**Detected Meaning Shifts (Rule 1.3):**\n"
        for shift in meaning_shifts:
            meaning_shift_context += f"- **{shift['word'].upper()}**: {shift['message']} (x{shift['count']})\n"

    output_template = "\n".join([f"{i+1}. [Rewrite sentence {i+1} to be STE-compliant]" for i in range(sentence_count)])
    prompt = (
    "You are an ASD-STE100 (Simplified Technical English) rewriter and validator. "
    "Rewrite the given text in a clear and precise way that conforms to all ASD‑STE100 rules.\n\n"
    "**STRICT INSTRUCTION:** Rewrite EXACTLY the same number of sentences as in the input.\n"
    "Keep each rewritten sentence fully aligned with the meaning of its corresponding input sentence. "
    "Do not merge, split, or combine ideas from different sentences. "
    "Each input sentence must correspond to exactly one rewritten sentence.\n"
    "**SIMPLIFICATION PRIORITY:**\n"
    "Always choose the simplest possible approved verb or phrase.\n"
    "Prefer short, common STE words over formal or technical synonyms.\n"
    "Examples:\n"
    "- use 'start' instead of 'initiate' or 'commence'\n"
    "- use 'make sure' instead of 'ensure' or 'confirm'\n"
    "- use 'use' instead of 'utilize'\n"
    "- use 'show' instead of 'exhibit'\n"
    "- use 'operate' instead of 'function'\n"
    "Do not create new synonyms not found in the dictionary warnings or STE rules.\n\n"

    "**INPUT TEXT TO REWRITE:**\n"
    f"*** BEGIN USER TEXT ***\n{text.strip()}\n*** END USER TEXT ***\n\n"
    f"This input contains {sentence_count} sentence(s).\n\n"
    f"{meaning_shift_context}"
    f"{formatted_dict_warnings}"
    "\n**CRITICAL STE RULES FOR REWRITE:**\n"
    "1. Use present tense unless past reference is required.\n"
    "2. Use imperative verb form for instructions.\n"
    "3. Write one idea per sentence.\n"
    "4. Use active voice only.\n"
    "5. Remove unnecessary words (e.g., 'prior to' → 'before', 'in order to' → 'to').\n"
    "6. Keep vocabulary simple, based on the STE approved dictionary.\n"
    "7. Do not use idioms, slang, or figurative language.\n\n"
    f"**REQUIRED OUTPUT FORMAT (EXACTLY {sentence_count} NUMBERED SENTENCE(S) ONLY):**\n"
    "Output ONLY the rewritten sentences, numbered sequentially (1., 2., etc.).\n"
    "Do not include explanations or comments; return only the STE-compliant sentences.\n"
    f"{output_template}\n"
    )

    try:
        ai_raw = ""
        if ENGINE.lower() == "gpt4all":
            with model.chat_session():
                ai_raw = model.generate(prompt, n_predict=MAX_TOKENS, temp=0.2)
        elif ENGINE.lower() == "llama":
            resp = model.create_completion(prompt=prompt, max_tokens=MAX_TOKENS, temperature=0.2, top_p=0.85)
            ai_raw = resp.get("choices", [{}])[0].get("text", "").strip()
        else:
            raise ValueError("Unsupported engine.")

        ai_sentences = extract_ai_rewrites(ai_raw, text)
        original_sentences = split_into_sentences(text)
        if len(ai_sentences) != len(original_sentences):
            logging.warning(f"AI mismatch: expected {len(original_sentences)}, got {len(ai_sentences)}")
            # Force rule‑based rewrite for any missing or merged sentences.
            fallback_sentences = []
            for i, orig in enumerate(original_sentences):
                if i < len(ai_sentences):
                    # Prevent merged content that contains multiple ideas.
                    # Optional: split on '.' or 'and' if too long.
                    single_sent = re.split(r'[.!?]+', ai_sentences[i])[0].strip()
                    fallback_sentences.append(single_sent)
                else:
                    fb = apply_basic_ste_compliance(orig, meaning_shifts, formatted_dict_warnings)
                    fallback_sentences.append(fb)
            ai_sentences = fallback_sentences
        final_sentences = ai_sentences[:sentence_count] if ai_sentences else []

        if len(final_sentences) < sentence_count:
            logging.warning("AI under-generated, using fallback.")
            originals = split_into_sentences(text)
            for i in range(len(final_sentences), sentence_count):
                fb = apply_basic_ste_compliance(originals[i], meaning_shifts, formatted_dict_warnings)
                final_sentences.append(fb)

        final_rewrite = "\n".join([f"{i+1}. {s}" for i, s in enumerate(final_sentences)])
        feedback = f"🤖 AI‑Generated STE‑Compliant Rewrite:\n{final_rewrite}"

        # ============================================================
        # ✅ POST‑REWRITE DICTIONARY VALIDATION
        # ============================================================
        joined_text = " ".join(final_sentences)
        post_issues = dictionary_check.analyze_text(joined_text)
        if post_issues:
            formatted_post_issues = "\n".join([f"- {issue}" for issue in post_issues])
            compliance_flag = "⚠️ Some unapproved terms remain after rewrite."
        else:
            formatted_post_issues = "✅ All words approved (dictionary clean)."
            compliance_flag = "✅ Fully STE‑compliant after re‑validation."

        feedback += (
            f"\n\n📘 Post‑Rewrite Dictionary Validation ({compliance_flag}):\n"
            f"{formatted_post_issues}"
        )

        logging.info("Post‑rewrite validation executed successfully.")
        return {"feedback": feedback, "meaning_shifts": meaning_shifts, "post_validation": post_issues}

    except Exception as e:
        logging.exception(f"Inference error: {e}")
        fallback = generate_fallback_rewrite(text, meaning_shifts, formatted_dict_warnings)
        return {
            "feedback": f"❌ Critical error: {e}\n\nFallback rewrite:\n{fallback}",
            "meaning_shifts": meaning_shifts
        }


# ============================================================
# Self‑test block
# ============================================================
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    try:
        model_instance = get_model()
        test_text = "Make sure that the valve is operable."
        dict_warn = "\n**DICTIONARY WARNINGS:**\n- 'OPERABLE' (POS: 'adj') is Unapproved in STE dictionary. Suggested alternative: 'CAN OPERATE'"
        result = analyze_ste(model_instance, test_text, dict_warn)
        print("\n--- TEST INPUT ---\n", test_text)
        print("\n--- ANALYSIS FEEDBACK ---\n", result["feedback"])
    except Exception as e:
        print(f"Model load failed for test: {e}")