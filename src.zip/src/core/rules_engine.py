"""
core/rules_engine.py — Rule validation for ASD‑STE compliance
"""
from dataclasses import dataclass
from typing import List, Dict, Any
import re
import json
import logging

@dataclass
class RuleResult:
    rule_id: str
    passed: bool
    comment: str
    suggestion: str = "" # Added suggestion field


def load_rules(config_path: str = "configs/asd_ste_rules.json") -> List[Dict[str, Any]]:
    """
    Loads STE rules from a JSON configuration file.
    Expects the JSON to have a top-level 'rules' key containing a list of rule dictionaries.
    """
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            rules_data = json.load(f)
        
        if "rules" in rules_data and isinstance(rules_data["rules"], list):
            rules_list = rules_data["rules"]
            logging.info(f"Loaded {len(rules_list)} STE rules from '{config_path}'")
            return rules_list
        else:
            logging.warning(f"JSON from '{config_path}' does not contain a top-level 'rules' list. Returning empty list.")
            return []
            
    except FileNotFoundError:
        logging.error(f"Rule configuration file not found at: '{config_path}'")
        return []
    except json.JSONDecodeError as e:
        logging.error(f"Error decoding JSON from '{config_path}': {e}")
        return []
    except Exception as e:
        logging.error(f"An unexpected error occurred while loading rules from '{config_path}': {e}")
        return []


def _detect_meaning_shifts_from_json(text: str, meaning_shifts_config: List[Dict[str, Any]]) -> List[RuleResult]:
    """
    Detects meaning shifts based on configurations from the JSON file for Rule 1.3.
    """
    results = []
    for shift in meaning_shifts_config:
        unapproved_pattern = shift.get("unapproved_pattern")
        message = shift.get("message")
        severity = shift.get("severity", "warning") # Default to warning if not specified in JSON

        if unapproved_pattern and message:
            matches = re.findall(unapproved_pattern, text, re.IGNORECASE)
            if matches:
                results.append(RuleResult(
                    rule_id="1.3",
                    passed=False,
                    comment=f"❌ Violation ({severity.upper()}): {message} ({len(matches)} match(es))."
                ))
    return results


def _check_sentence_word_count(text: str, rule_id: str, is_procedural: bool, params: Dict[str, Any]) -> RuleResult:
    """Programmatic check for Rule 4.1 / 8.7: Sentence word count limits."""
    sentences = re.split(r'[.!?]+', text)
    sentences = [s.strip() for s in sentences if s.strip()]
    
    max_words = params.get("max_words_descriptive", 25)
    if is_procedural:
        max_words = params.get("max_words_procedural", 20)
    
    violations = []
    for i, sentence in enumerate(sentences):
        word_count = len(re.findall(r'\b\w+\b', sentence)) # More robust word count
        if word_count > max_words:
            violations.append(f"'{sentence}' ({word_count} words > {max_words})")
    
    if violations:
        return RuleResult(rule_id, False, f"❌ Violation (WARNING): Sentence(s) exceed word limit: {'; '.join(violations)}")
    return RuleResult(rule_id, True, "✅ Passed: All sentences within word limits.")


def _check_paragraph_length(text: str, rule_id: str, params: Dict[str, Any]) -> RuleResult:
    """Programmatic check for Rule 6.6: Paragraph length."""
    max_chars = params.get("max_chars", 200)
    
    paragraphs = re.split(r'\n{2,}', text) # Split by two or more newlines for paragraphs
    paragraphs = [p.strip() for p in paragraphs if p.strip()]

    violations = []
    for i, para in enumerate(paragraphs):
        char_count = len(re.sub(r'\s', '', para)) # Character count excluding whitespace
        if char_count > max_chars:
            violations.append(f"Paragraph {i+1} ({char_count} chars > {max_chars}) - snippet: '{para[:min(50, len(para))]}...'")
    
    if violations:
        return RuleResult(rule_id, False, f"❌ Violation (INFO): Paragraph(s) exceed character limit: {'; '.join(violations)}")
    return RuleResult(rule_id, True, "✅ Passed: All paragraphs within character limits.")


def _check_technical_noun_as_verb(text: str, rule_id: str, params: Dict[str, Any]) -> List[RuleResult]:
    """Programmatic check for Rule 1.7: Do not use technical nouns as verbs."""
    technical_nouns = [re.escape(tn) for tn in params.get("technical_nouns_as_verbs", [])]
    if not technical_nouns:
        return []
    
    # Heuristic: Look for a known technical noun followed by an object (article + noun/pronoun or just a noun)
    # This also tries to ensure it's at the start of a sentence or shortly after punctuation
    pattern = r"(?:^|[.!?]\\s*)(?:\w+\s+){0,2}(" + "|".join(technical_nouns) + r")\b\s+(?:the|a|an|this|these|your|my|his|her|its|our|their)?\s+\w+"
    matches = re.findall(pattern, text, re.IGNORECASE)
    
    if matches:
        # Use set to avoid duplicate reporting if same word matches multiple times
        matched_words = set(m.lower() for m in matches)
        return [RuleResult(rule_id, False, f"❌ Violation (ERROR): Potential use of technical noun(s) '{', '.join(matched_words)}' as a verb. Consult STE dictionary/examples.")]
    return []


def _check_technical_verb_as_noun(text: str, rule_id: str, params: Dict[str, Any]) -> List[RuleResult]:
    """Programmatic check for Rule 1.13: Do not use technical verbs as nouns."""
    technical_verbs = [re.escape(tv) for tv in params.get("technical_verbs_as_nouns", [])]
    if not technical_verbs:
        return []
    
    # Heuristic: Look for a known technical verb preceded by an article or possessive, acting as a noun
    pattern = r"\b(?:the|a|an|this|that|my|your|his|her|its|our|their)\s+(" + "|".join(technical_verbs) + r")\b"
    matches = re.findall(pattern, text, re.IGNORECASE)

    if matches:
        matched_words = set(m.lower() for m in matches)
        return [RuleResult(rule_id, False, f"❌ Violation (ERROR): Potential use of technical verb(s) '{', '.join(matched_words)}' as a noun. Consult STE dictionary/examples.")]
    return []


def _check_action_description_noun(text: str, rule_id: str, params: Dict[str, Any]) -> List[RuleResult]:
    """Programmatic check for Rule 3.7: Use an approved verb to describe an action (not a noun)."""
    non_ste_nouns = [re.escape(n) for n in params.get("non_ste_noun_verbs", [])]
    if not non_ste_nouns:
        return []
    
    # Heuristic: Look for common verb phrases followed by these noun-forms
    # (e.g., "perform the inspection", "do a repair", "make an adjustment")
    pattern = r"\b(perform|do|make)\s+(?:the|a|an)?\s+(" + "|".join(non_ste_nouns) + r")\b"
    matches = re.findall(pattern, text, re.IGNORECASE)
    
    suggestions = {
        "inspection": "inspect", "inspections": "inspect",
        "repair": "repair", "repairs": "repair",
        "assembly": "assemble", "assemblies": "assemble",
        "removal": "remove", "removals": "remove",
        "adjustment": "adjust", "adjustments": "adjust",
        "operation": "operate", "operations": "operate"
    }

    if matches:
        violation_details = []
        for verb_phrase, noun_form in set(matches): # Use set to avoid duplicates
            noun_form_lower = noun_form.lower()
            action_verb = suggestions.get(noun_form_lower, "").capitalize()
            if action_verb:
                violation_details.append(f"'{verb_phrase} {noun_form}' (Use direct verb '{action_verb}' instead of noun form).")
            else:
                violation_details.append(f"'{verb_phrase} {noun_form}' (Unapproved noun form used for action).")
        
        return [RuleResult(rule_id, False, f"❌ Violation (INFO): Action described as noun: {'; '.join(violation_details)} Consult STE dictionary/examples.")]
    return []


def _check_rule_4_5_articles(text: str, rule_id: str, params: Dict[str, Any]) -> List[RuleResult]:
    """Programmatic check for Rule 4.5: Articles and demonstrative adjectives (formerly 2.3)."""
    results = []
    
    # Part 1: Do not use article before noun with alphanumeric identifier
    alpha_numeric_pattern = params.get("alpha_numeric_pattern")
    if alpha_numeric_pattern:
        found_alpha_numeric = re.findall(alpha_numeric_pattern, text, re.IGNORECASE)
        if found_alpha_numeric:
            results.append(RuleResult(
                rule_id, False, 
                f"❌ Violation (WARNING): Article used before alphanumeric identifier: {', '.join(set(found_alpha_numeric))}. Example: 'Tag circuit breaker 36L7'."
            ))
    
    if not results: # If no alphanumeric violation, report as passed
         results.append(RuleResult(rule_id, True, "✅ Passed: Article usage for alphanumeric identifiers and general omission heuristics."))
    
    return results

def _check_one_idea_per_sentence(text: str, rule_id: str) -> List[RuleResult]:
    """Programmatic check for Rule 6.3: One idea per sentence. Very heuristic for regex."""
    results = []
    # Using a more robust sentence splitter for this check
    sentences = re.split(r'(?<=[.!?])\s+', text) # Split after punctuation and whitespace
    sentences = [s.strip() for s in sentences if s.strip()]

    # Expanded list of complex conjunctions or linking words that might indicate multiple ideas
    complex_conjunctions = r'\b(and|but|or|so|yet|for|nor|while|whereas|although|though|even though|because|since|as|if|unless|until|when|where|who|which|that|in addition|furthermore|however|moreover|consequently|therefore|thus|hence)\b'
    
    for sentence in sentences:
        words = re.findall(r'\b\w+\b', sentence) # Count actual words
        if len(words) > 12: # Only check longer sentences (a tunable heuristic)
            found_conjunctions = re.findall(complex_conjunctions, sentence, re.IGNORECASE)
            # A longer sentence with multiple different complex conjunctions is a red flag
            # Tunable: Check if count of *unique* conjunctions is > 1 for a long sentence
            if len(set(found_conjunctions)) > 1: 
                results.append(RuleResult(
                    rule_id, False,
                    f"❌ Violation (WARNING): Sentence '{sentence[:80]}...' may contain more than one idea (multiple unique complex conjunctions detected: {', '.join(set(found_conjunctions))})."
                ))
    if not results:
        results.append(RuleResult(rule_id, True, "✅ Passed: Sentences generally contain one idea (heuristic check)."))
    return results


def _check_multi_word_nouns(text: str, rule_id: str, params: Dict[str, Any]) -> List[RuleResult]:
    """Programmatic check for Rule 2.1: Limit multi-word nouns."""
    max_words = params.get("max_words_in_multiword_noun", 3)
    
    words = re.findall(r'\b\w+\b', text) # Get all words, preserving case if meaningful
    
    violations = []
    current_cluster_words = []
    
    # A list of common function words (articles, prepositions, conjunctions, some verbs)
    # This helps in identifying potential noun phrase boundaries.
    function_words = {"a", "an", "the", "of", "in", "on", "for", "with", "to", "is", "are", "was", "were", "and", "or", "but", "by", "from", "at", "as"}
    
    for word in words:
        # If a word is predominantly capitalized (e.g., technical name) or not a common function word
        if word.isupper() or word.istitle() or (word.lower() not in function_words):
            current_cluster_words.append(word)
        else: # Function word or entirely lowercase, breaks the cluster
            if len(current_cluster_words) > max_words:
                violations.append(" ".join(current_cluster_words))
            current_cluster_words = [] # Reset for next potential cluster
    
    # Check any remaining cluster at the end of the text
    if len(current_cluster_words) > max_words:
        violations.append(" ".join(current_cluster_words))

    if violations:
        return [RuleResult(rule_id, False, f"❌ Violation (WARNING): Multi-word noun(s) exceed {max_words} words (heuristic check): {'; '.join(violations)}")]
    return [RuleResult(rule_id, True, "✅ Passed: Multi-word noun limits respected (heuristic check).")]

# ============================================================
# FILE: src/core/rules_engine.py
# ADD THIS NEW FUNCTION
# ============================================================

def _check_pronoun_ambiguity(text: str, rule_id: str) -> List[RuleResult]:
    """
    Programmatic check for Rule 9.5: Pronoun usage ambiguity.
    Only flag when pronouns could be ambiguous (multiple pronouns close together).
    """
    results = []
    
    # Split into sentences
    sentences = re.split(r'[.!?]+', text)
    sentences = [s.strip() for s in sentences if s.strip()]
    
    # Pattern for consecutive pronouns that might be ambiguous
    # E.g., "They said it was theirs" = 3 pronouns, suspicious
    ambiguous_pattern = r'\b(?:it|they|them|this|that|he|she|him|her|his|its)\b.*?\b(?:it|they|them|this|that|he|she|him|her|his|its)\b.*?\b(?:it|they|them|this|that|he|she|him|her|his|its)\b'
    
    violations = []
    for sentence in sentences:
        words = re.findall(r'\b\w+\b', sentence)
        
        # Only check sentences longer than 15 words (shorter ones less ambiguous)
        if len(words) > 15:
            # Count pronouns
            pronouns = re.findall(r'\b(?:it|they|them|this|that|he|she|him|her|his|its)\b', sentence, re.IGNORECASE)
            
            # Flag if 4+ pronouns in a long sentence (potential ambiguity)
            if len(pronouns) >= 4:
                violations.append(
                    RuleResult(
                        rule_id, False,
                        f"⚠️ WARNING (INFO): Sentence '{sentence[:70]}...' contains {len(pronouns)} pronouns. "
                        f"Review for clarity to ensure pronoun references are clear."
                    )
                )
    
    if not violations:
        results.append(
            RuleResult(rule_id, True, "✅ Passed: Pronoun usage appears clear (no excessive pronoun density detected).")
        )
    else:
        results.extend(violations)
    
    return results

def apply_rules(text: str, config_path: str = "configs/asd_ste_rules.json") -> List[RuleResult]:
    """
    Applies a set of predefined STE rules to the given text.
    Combines regex pattern rules (from JSON) and specific programmatic checks.
    """
    rules_config = load_rules(config_path)
    all_results = []

    # Determine if text is procedural or descriptive for sentence word count
    # Heuristic: check if any line starts with a list marker or a common imperative verb
    is_procedural_text_flag = False
    
    lines = text.split('\n')
    for line in lines:
        stripped_line = line.strip().lower()
        if re.match(r"^\s*(?:[1-9]\d*\.?|\*|-|\+)\s+\w+", stripped_line): # Starts with number. / bullet
            is_procedural_text_flag = True
            break
        first_word_match = re.match(r"^\W*(\w+)", stripped_line)
        if first_word_match:
            first_word = first_word_match.group(1)
            imperative_starters = {"do", "make", "set", "install", "remove", "check", "adjust", "apply", "use", "turn", "clean", "examine", "verify", "connect", "disconnect", "open", "close"}
            if first_word in imperative_starters:
                is_procedural_text_flag = True
                break

    logging.info(f"Text identified as {'procedural' if is_procedural_text_flag else 'descriptive'} for word count limits.")


    for rule_dict in rules_config:
        rid = rule_dict.get("id", "UNKNOWN")
        desc = rule_dict.get("description", "")
        severity = rule_dict.get("severity", "info")
        programmatic_check_needed = rule_dict.get("programmatic_check", False)
        
        rule_results_for_this_rule = []

        if programmatic_check_needed:
            params = rule_dict.get("params", {})
            
            # --- Programmatic Checks ---
            if rid == "1.1" or rid == "1.2" or rid == "1.4" or rid == "3.1": # Conceptual/dictionary-enforced rules
                pass # Handled by dictionary_check.py or are conceptual rules
            elif rid == "1.7": # Technical nouns as verbs
                rule_results_for_this_rule.extend(_check_technical_noun_as_verb(text, rid, params))
            elif rid == "1.13": # Technical verbs as nouns
                rule_results_for_this_rule.extend(_check_technical_verb_as_noun(text, rid, params))
            elif rid == "2.1": # Multi-word nouns
                rule_results_for_this_rule.extend(_check_multi_word_nouns(text, rid, params))
            elif rid == "3.7": # Action description (noun forms of verbs)
                rule_results_for_this_rule.extend(_check_action_description_noun(text, rid, params))
            elif rid == "4.1" or rid == "8.7": # Sentence word count limits
                rule_results_for_this_rule.append(_check_sentence_word_count(text, rid, is_procedural_text_flag, params))
            elif rid == "4.5": # Articles and demonstrative adjectives (formerly 2.3)
                rule_results_for_this_rule.extend(_check_rule_4_5_articles(text, rid, params))
            elif rid == "6.3": # One idea per sentence
                rule_results_for_this_rule.extend(_check_one_idea_per_sentence(text, rid))
            elif rid == "6.6": # Paragraph length
                rule_results_for_this_rule.append(_check_paragraph_length(text, rid, params))
            elif rid == "9.5": # Pronoun usage ambiguity
                rule_results_for_this_rule.extend(_check_pronoun_ambiguity(text, rid))
            
            all_results.extend(rule_results_for_this_rule)
            continue # Move to the next rule after programmatic check
        
        # --- Regex-based Checks ---
        pattern = rule_dict.get("pattern")
        match_means_violation = rule_dict.get("match_means_violation", True)
        
        if pattern is None:
            continue # Skip if no pattern for direct regex check

        try:
            # Debugging for Rule 8.6
            if rid == "8.6":
                logging.debug(f"\n--- Debugging Rule 8.6 ---")
                logging.debug(f"Input text for Rule 8.6: '{text}' (Length: {len(text)})")
                logging.debug(f"Pattern for Rule 8.6: '{pattern}'")
                found = re.findall(pattern, text) # No IGNORECASE for abbreviations to strictly match uppercase
                logging.debug(f"Matches found for Rule 8.6: {found} (Count: {len(found)})")
                logging.debug(f"--- End Debugging Rule 8.6 ---\n")
            else:
                 found = re.findall(pattern, text, re.IGNORECASE)
            
            if match_means_violation:
                passed = len(found) == 0
            else:
                passed = len(found) > 0
            
            comment = (
                f"✅ Passed: {desc}"
                if passed else f"❌ Violation ({severity.upper()}): {desc} ({len(found)} match(es) for pattern '{pattern}')."
            )
            all_results.append(RuleResult(rid, passed, comment))
        except re.error as e:
            logging.error(f"Invalid regex pattern in rule {rid} from {config_path}: {e}. Pattern: '{pattern}'")
            all_results.append(RuleResult(rid, True, f"⚠️ Rule pattern error for rule {rid}: {e} - check regex '{pattern}'."))

    # --- Meaning Shift Detection (Rule 1.3) ---
    rule_1_3_config = next((r for r in rules_config if r["id"] == "1.3"), None)
    if rule_1_3_config and "meaning_shifts" in rule_1_3_config:
        meaning_shift_results = _detect_meaning_shifts_from_json(text, rule_1_3_config["meaning_shifts"])
        all_results.extend(meaning_shift_results)

    logging.info(f"{len(all_results)} rules evaluated.")
    return all_results