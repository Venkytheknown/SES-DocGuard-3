"""
core/config.py — Central configuration for ASD‑STE Checker
"""

# Engine options: "gpt4all" or "llama"
# Choose one by uncommenting and delete/comment out the other.
ENGINE = "gpt4all"   # Set to gpt4all based on your clarification
# ENGINE = "llama"

# Path to local model. Ensure this path is correct relative to the script's execution.
# This should be the path to your GPT4All model file (.gguf or other compatible format).
MODEL_PATH = "models/mistral-7b-instruct-v0.2.Q4_K_M.gguf" # Keep your specific model file here

# Model and performance settings
MAX_TOKENS = 1024
N_THREADS = 8